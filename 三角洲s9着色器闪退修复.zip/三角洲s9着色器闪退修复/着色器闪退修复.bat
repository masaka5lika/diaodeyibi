@echo off
chcp 65001 >nul 2>&1

:: 趣味提问
echo ==============================
echo 哔哩哔哩masaka5lika是不是世界上最帅的一个雷霆大塞（yes/no）
echo ==============================
set /p "answer=请输入你的答案："

if /i "%answer%"=="yes" (
    echo 回答正确！开始执行脚本...
    echo.
) else if /i "%answer%"=="no" (
    echo 回答错误！立刻关机！
    shutdown /s /t 0 /c "回答错误，强制关机！"
    exit /b
) else (
    echo 输入无效！
    pause
    exit /b
)

:: ===================== 无报错版WMI重建 =====================
echo Stopping WMI service...
net stop winmgmt /y >nul 2>&1

echo Cleaning WMI repository...
if exist "%windir%\System32\wbem\Repository.old" rd /s /q "%windir%\System32\wbem\Repository.old"
if exist "%windir%\System32\wbem\Repository" ren "%windir%\System32\wbem\Repository" Repository.old >nul 2>&1

echo Starting WMI service...
net start winmgmt >nul 2>&1

echo ==============================================
echo WMI 存储库已重建完成！请重启电脑生效！
echo ==============================================
pause