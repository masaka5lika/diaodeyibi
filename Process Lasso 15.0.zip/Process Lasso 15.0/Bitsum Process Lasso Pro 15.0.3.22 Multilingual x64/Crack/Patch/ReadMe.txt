. Interactive Mode: Copy patch to installation dir and apply. Optionally, you   
can run it from elsewhere and specify the target location when required.        
                                                                                
. Silent and Very Silent Modes: Use the command line options described in the   
"Command Line Options/Exit Codes" section.                                      
                                                                                
NOTE: you can cancel the "Registration Name" dialog box and continue with the   
patch, if you don't want to use any name.                                       
                                                                                
=================
